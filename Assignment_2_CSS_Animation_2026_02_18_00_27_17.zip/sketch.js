function setup() {
  createCanvas(600, 600);

}

function draw() {
  background("#03A9F4");
  
   if(mouseIsPressed){ 
  fill ("black")
  print("RELEASE THEM")
  text("RELEASE THEM",502, 196,290)
  }else{
    fill("black")
    print("1..2..123")
    text('1..2..123',474, 329,190 )
  }
  fill("yellow")
  circle (70, 70, 100)
  
  
  fill ("white")
  noStroke(202, 133, 50)
  
  circle(202, 133, 50)
  circle (222, 144, 70)
  circle(168, 172, 100)
  ellipse( 242, 190, 68)
  circle (429, 74,80)
  circle(470, 94,60)
 circle(350, 95,90)
  circle(382, 56, 45)
  
  fill("blue")
  rect(0, 427.59999990463257,600.59999990463257,560)
  fill("black")
   rect(92, 500,80, 444)
  fill("rgb(45,69,45)")
  rect(92, 410,80,175)
  
   stroke('grey');
  strokeWeight(5);

  line(132, 582, 132, 413.2)
  fill("orange")
  noStroke(76, 340, 115)
  square(76, 340, 115)
  square (50,340,80)
  square(140,340,80)
  
  fill('red')
  triangle(276, 322.59999990463257,290, 327.59999990463257, 286,313.59999990463257 )
  
  
  fill("brown")
  noStroke
 rect(110, 300, 50, 40)
  circle(130, 266, 120)
  rect(55, 420,15, 95 )
  rect (198, 420,15, 95)
  circle(205, 515.5999999046326 ,25 )
  circle(62, 515 ,25)
  
  fill("black")
    arc(130, 200, 80, 150, -560, PI + QUARTER_PI, OPEN);
  circle(167, 200, 100)
  circle (100,200,100)
  circle (60,250,95)
  circle (50,300,70)
  circle (200,250,95)
  circle (210,300,75)
  
  fill("gold")
  triangle(359, 258,372, 262,367, 254)
  ellipse(368,225,120, 60)
  
  fill("red")
  ellipse(286,288,90,55)
  
  if(mouseIsPressed){ 
  strokeWeight(2);
  stroke('grey')
    line(329, 469 ,282, 326)
  line(399, 492 , 366, 259 )
  }else{
strokeWeight(2);
    noStroke()
  stroke("grey")
  line(206, 517 ,282, 326 )
  line(206, 517, 366, 259 )
  }
  
  //text(mouseX + ", " + mouseY, 20, 20) ;   
  
}

function mouseReleased() {
  print(mouseX + ", " + mouseY) ;
}